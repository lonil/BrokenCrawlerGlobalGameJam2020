﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class RandomRange
{
    public static int Randomrange(int min, int max)
    {
        return Random.Range(min, max);
    }
}
   
