﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu]
public class IntScriptableObject : ScriptableObject
{
    public int value; 
}
